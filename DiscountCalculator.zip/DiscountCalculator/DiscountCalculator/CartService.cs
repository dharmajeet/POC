using DiscountCalculator.DTO;
using DiscountCalculator.DTO.Discount;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiscountCalculator
{
    public interface ICartService
    {
        void AddItem(ProductBase product);
        decimal GetTotalPrice();

    }
    public class CartService : ICartService
    {
        private IList<ProductBase> _productBases;
        private IDiscountService _discountService;

        public CartService(IDiscountService discountService)
        {
            _discountService = discountService;
            _productBases = new List<ProductBase>();
        }

        public void AddItem(ProductBase product)
        {
            _productBases.Add(product);
        }

        public decimal GetTotalPrice()
        {
            return _productBases.CalculatePrice(_discountService);
        }


    }

}
