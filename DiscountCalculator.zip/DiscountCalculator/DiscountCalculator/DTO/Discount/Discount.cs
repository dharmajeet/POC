using System;
using System.Collections.Generic;
using System.Linq;

namespace DiscountCalculator.DTO.Discount
{
    public abstract class DiscountPromo
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime ExpireOn { get; set; }

        public abstract decimal CalculateDiscount(IEnumerable<ProductBase> productInCart);

    }

    public class FlatPercentageDoscount : DiscountPromo
    {
        private readonly int _discountPecrentage;
        public FlatPercentageDoscount(int discountPecrentage)
        {
            _discountPecrentage = discountPecrentage;
        }
        public override decimal CalculateDiscount(IEnumerable<ProductBase> productInCart)
        {

            return productInCart.Sum(item => item.ProductPrice.Price) * _discountPecrentage / 100;
        }
    }

    public class Buy2And10PercentDiscount : DiscountPromo
    {
        private readonly int _discountPecrentage;
        public Buy2And10PercentDiscount(int discountPecrentage)
        {
            _discountPecrentage = discountPecrentage;
        }
        public override decimal CalculateDiscount(IEnumerable<ProductBase> productInCart)
        {
            if (productInCart.Count() > 1)
                return productInCart.Sum(item => item.ProductPrice.Price) * _discountPecrentage / 100;
            return decimal.Zero;
        }
    }

    public class BuyNGetXFreeDiscount : DiscountPromo
    {
        private readonly int _buyQuantity;
        private readonly int _freeQuantity;
        private readonly bool _isLowPriceItemFree;

        public BuyNGetXFreeDiscount(int buyQuantity, int freeQuantity, bool isLowPriceItemFree = true)
        {
            _buyQuantity = buyQuantity;
            _freeQuantity = freeQuantity;
            _isLowPriceItemFree = isLowPriceItemFree;
        }
        public override decimal CalculateDiscount(IEnumerable<ProductBase> productInCart)
        {
            var freeItemCount = productInCart.Count() / _buyQuantity;
            var totalFreeItem = freeItemCount * _freeQuantity;

            if (_isLowPriceItemFree)
                return productInCart.OrderBy(item => item.ProductPrice.Price).Take(totalFreeItem).Sum(item => item.ProductPrice.Price);
            else
                return productInCart.OrderByDescending(item => item.ProductPrice.Price).Take(totalFreeItem).Sum(item => item.ProductPrice.Price);

            return decimal.Zero;
        }
    }

    public class CustomDiscount : DiscountPromo
    {
        private readonly Func<IEnumerable<ProductBase>, decimal> _predicate;

        public CustomDiscount(Func<IEnumerable<ProductBase>,decimal> predicate)
        {
            _predicate = predicate;
        }
        public override decimal CalculateDiscount(IEnumerable<ProductBase> productInCart)
        {
            return _predicate.Invoke(productInCart);
        }
    }

}
