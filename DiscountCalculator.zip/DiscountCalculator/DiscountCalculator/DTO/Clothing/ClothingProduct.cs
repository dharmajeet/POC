using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiscountCalculator.DTO.Clothing
{
    public class ClothingProduct : ProductBase
    {
        public ClothSize Size { get; set; }

    }

    public enum ClothSize
    {
        S,
        M,
        L,
        XL,
        XXL
    }
}
