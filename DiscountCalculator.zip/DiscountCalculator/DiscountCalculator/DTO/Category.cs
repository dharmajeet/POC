using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiscountCalculator.DTO
{
    public enum Category
    {
        Books = 1,
        Clothing = 2,
    }
}
