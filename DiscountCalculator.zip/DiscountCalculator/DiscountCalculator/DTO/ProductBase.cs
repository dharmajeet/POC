using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiscountCalculator.DTO
{
   public abstract class ProductBase
    {
        public Category Category { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public ProductPrice ProductPrice { get; set; }
    }
}
