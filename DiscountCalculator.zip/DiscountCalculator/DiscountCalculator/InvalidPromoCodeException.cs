﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DiscountCalculator
{
   public class InvalidPromoCodeException :Exception
    {
    }
}
