using DiscountCalculator.DTO.Discount;
using System.Collections.Generic;
using System.Linq;


namespace DiscountCalculator
{
    public interface IDiscountService
    {
        void AddDiscount(DiscountPromo discount);
        IEnumerable<DiscountPromo> GetDiscounts();
        void AddDiscountedProduct(string discountPromoCode, string productCode);
        IReadOnlyDictionary<string, DiscountPromo> GetDiscountedProduct(string[] productCode =null);
    }

    public class DiscountService : IDiscountService
    {
        private IList<DiscountPromo> _discountPromos;
        private IDictionary<string, DiscountPromo> _discountedProduct;


        public DiscountService()
        {
            _discountPromos = new List<DiscountPromo>();
            _discountedProduct = new Dictionary<string, DiscountPromo>();
        }
        public void AddDiscount(DiscountPromo discount)
        {
            _discountPromos.Add(discount);
        }

        public void AddDiscountedProduct(string discountPromoCode, string productCode)
        {
            var promo = _discountPromos.FirstOrDefault(item => item.Code.Equals(discountPromoCode)) ?? throw new InvalidPromoCodeException();

            _discountedProduct.Add(productCode, promo);
        }

        public IReadOnlyDictionary<string, DiscountPromo> GetDiscountedProduct(string[] productCode =null)
        {
            return _discountedProduct as IReadOnlyDictionary<string, DiscountPromo>;
        }

        public IEnumerable<DiscountPromo> GetDiscounts()
        {
            return _discountPromos;
        }
    }
}
